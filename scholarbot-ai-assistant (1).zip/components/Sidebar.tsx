
import React from 'react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ sessions, currentSessionId, onSelectSession, onNewChat }) => {
  return (
    <div className="w-80 h-full bg-slate-900 flex flex-col hidden lg:flex border-r border-slate-800">
      <div className="p-6 flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <i className="fa-solid fa-book-open-reader text-white text-xl"></i>
          </div>
          <div>
            <h1 className="text-white font-bold text-lg tracking-tight">ScholarBot</h1>
            <p className="text-slate-400 text-xs font-medium uppercase tracking-widest">Academic Hub</p>
          </div>
        </div>

        <button 
          onClick={onNewChat}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all duration-200 font-semibold shadow-lg shadow-indigo-600/20 group"
        >
          <i className="fa-solid fa-plus text-sm group-hover:rotate-90 transition-transform duration-300"></i>
          New Chat
        </button>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar px-3 space-y-1">
        <div className="px-3 mb-2">
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">Recent Inquiries</p>
        </div>
        {sessions.length === 0 ? (
          <div className="px-4 py-8 text-center">
            <p className="text-slate-500 text-sm">No recent chats.</p>
          </div>
        ) : (
          sessions.map((session) => (
            <button
              key={session.id}
              onClick={() => onSelectSession(session.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative ${
                currentSessionId === session.id 
                  ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-600/20' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-transparent'
              }`}
            >
              <i className={`fa-regular fa-message text-sm ${currentSessionId === session.id ? 'text-indigo-400' : 'text-slate-500'}`}></i>
              <span className="truncate text-sm font-medium flex-1 text-left">{session.title}</span>
              {currentSessionId === session.id && (
                <div className="absolute left-0 w-1 h-6 bg-indigo-500 rounded-r-full"></div>
              )}
            </button>
          ))
        )}
      </div>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-700/50">
          <p className="text-xs text-slate-400 font-medium leading-relaxed">
            ScholarBot is here to support your learning journey. For urgent school matters, please contact the office.
          </p>
          <a href="#" className="mt-2 text-indigo-400 text-xs font-semibold hover:text-indigo-300 transition-colors flex items-center gap-1">
            School Directory <i className="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
          </a>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
