
import React from 'react';
import { Message, MessagePart } from '../types';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  
  const renderContent = () => {
    if (typeof message.content === 'string') {
      return (
        <div className="prose prose-sm max-w-none break-words whitespace-pre-wrap">
          {message.content}
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {message.content.map((part, idx) => {
          if (part.text) {
            return (
              <div key={idx} className="prose prose-sm max-w-none break-words whitespace-pre-wrap">
                {part.text}
              </div>
            );
          }
          if (part.inlineData) {
            return (
              <div key={idx} className="mt-2 rounded-lg overflow-hidden border border-gray-200 bg-gray-50 max-w-xs">
                <img 
                  src={`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`} 
                  alt="Attachment" 
                  className="w-full h-auto object-cover"
                />
              </div>
            );
          }
          return null;
        })}
      </div>
    );
  };

  return (
    <div className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} mb-6 group`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full shadow-sm border ${
          isUser ? 'ml-3 bg-indigo-600 border-indigo-500' : 'mr-3 bg-white border-slate-200'
        }`}>
          {isUser ? (
            <i className="fa-solid fa-user text-white text-xs"></i>
          ) : (
            <i className="fa-solid fa-graduation-cap text-indigo-600 text-xs"></i>
          )}
        </div>
        
        <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
          <div className={`px-4 py-3 rounded-2xl shadow-sm border ${
            isUser 
              ? 'bg-indigo-600 text-white border-indigo-500 rounded-tr-none' 
              : 'bg-white text-slate-800 border-slate-200 rounded-tl-none'
          }`}>
            {renderContent()}
          </div>
          <span className="text-[10px] text-slate-400 mt-1 mx-1 font-medium tracking-wide uppercase">
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
