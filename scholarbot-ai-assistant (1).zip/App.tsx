
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Sidebar from './components/Sidebar';
import ChatMessage from './components/ChatMessage';
import { Message, ChatSession, Role, MessagePart } from './types';
import { SUGGESTED_PROMPTS } from './constants';
import { generateChatResponse, fileToBase64 } from './services/geminiService';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [attachments, setAttachments] = useState<{file: File, base64: string}[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentSession = sessions.find(s => s.id === currentSessionId) || null;

  useEffect(() => {
    scrollToBottom();
  }, [currentSession?.messages, isProcessing]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleNewChat = useCallback(() => {
    const newId = uuidv4();
    const newSession: ChatSession = {
      id: newId,
      title: 'New Conversation',
      messages: [],
      createdAt: new Date(),
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newId);
  }, []);

  const handleSelectSession = (id: string) => {
    setCurrentSessionId(id);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      // Fix: Explicitly cast the ArrayLike FileList to File[] to ensure the map iterator 'file' has the correct type.
      const files = Array.from(e.target.files) as File[];
      const newAttachments = await Promise.all(
        files.map(async file => ({
          file,
          base64: await fileToBase64(file)
        }))
      );
      setAttachments(prev => [...prev, ...newAttachments]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const sendMessage = async (text?: string) => {
    const messageText = text || input;
    if ((!messageText.trim() && attachments.length === 0) || isProcessing || !currentSessionId) return;

    setIsProcessing(true);
    setInput('');
    
    const userMessageParts: MessagePart[] = [];
    if (messageText.trim()) {
      userMessageParts.push({ text: messageText });
    }
    
    attachments.forEach(att => {
      userMessageParts.push({
        inlineData: {
          mimeType: att.file.type,
          data: att.base64
        }
      });
    });

    const userMessage: Message = {
      id: uuidv4(),
      role: 'user',
      content: userMessageParts,
      timestamp: new Date(),
    };

    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        const title = s.messages.length === 0 ? (messageText.substring(0, 30) || 'New Inquiry') : s.title;
        return { ...s, messages: [...s.messages, userMessage], title };
      }
      return s;
    }));

    setAttachments([]);

    try {
      const history = (currentSession?.messages || []).map(m => {
        let parts: any[] = [];
        if (typeof m.content === 'string') {
          parts = [{ text: m.content }];
        } else {
          parts = m.content.map(p => {
            if (p.text) return { text: p.text };
            if (p.inlineData) return { inlineData: p.inlineData };
            return null;
          }).filter(Boolean);
        }
        return {
          role: m.role === 'assistant' ? 'model' : m.role,
          parts
        };
      });

      // Add the current user message to history
      history.push({
        role: 'user',
        parts: userMessageParts.map(p => {
          if (p.text) return { text: p.text };
          if (p.inlineData) return { inlineData: p.inlineData };
          return null;
        }).filter(Boolean)
      });

      const assistantMessageId = uuidv4();
      const assistantMessage: Message = {
        id: assistantMessageId,
        role: 'assistant',
        content: '',
        timestamp: new Date(),
        isStreaming: true
      };

      setSessions(prev => prev.map(s => {
        if (s.id === currentSessionId) {
          return { ...s, messages: [...s.messages, assistantMessage] };
        }
        return s;
      }));

      let accumulatedText = "";
      await generateChatResponse(history, (chunk) => {
        accumulatedText += chunk;
        setSessions(prev => prev.map(s => {
          if (s.id === currentSessionId) {
            return {
              ...s,
              messages: s.messages.map(m => 
                m.id === assistantMessageId 
                  ? { ...m, content: accumulatedText } 
                  : m
              )
            };
          }
          return s;
        }));
      });

      setSessions(prev => prev.map(s => {
        if (s.id === currentSessionId) {
          return {
            ...s,
            messages: s.messages.map(m => 
              m.id === assistantMessageId 
                ? { ...m, isStreaming: false } 
                : m
            )
          };
        }
        return s;
      }));

    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        id: uuidv4(),
        role: 'assistant',
        content: "I'm sorry, I encountered an error. Please check your connection or try again later.",
        timestamp: new Date()
      };
      setSessions(prev => prev.map(s => {
        if (s.id === currentSessionId) {
          return { ...s, messages: [...s.messages, errorMessage] };
        }
        return s;
      }));
    } finally {
      setIsProcessing(false);
    }
  };

  // Create initial session if none exist
  useEffect(() => {
    if (sessions.length === 0) {
      handleNewChat();
    }
  }, [sessions.length, handleNewChat]);

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar 
        sessions={sessions} 
        currentSessionId={currentSessionId} 
        onSelectSession={handleSelectSession} 
        onNewChat={handleNewChat}
      />

      <main className="flex-1 flex flex-col min-w-0 bg-white shadow-2xl relative z-10">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-6 border-b border-slate-100 bg-white/80 backdrop-blur-md sticky top-0 z-20">
          <div className="flex items-center gap-4 lg:hidden">
             <button className="p-2 -ml-2 text-slate-500 hover:text-indigo-600 transition-colors">
                <i className="fa-solid fa-bars text-xl"></i>
             </button>
             <div className="flex items-center gap-2">
                <i className="fa-solid fa-graduation-cap text-indigo-600 text-xl"></i>
                <span className="font-bold text-slate-800">ScholarBot</span>
             </div>
          </div>
          
          <div className="hidden lg:flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-400 uppercase tracking-widest text-[10px]">Session Context</span>
            <div className="h-4 w-[1px] bg-slate-200 mx-2"></div>
            <h2 className="text-slate-800 font-semibold truncate max-w-md">
              {currentSession?.title || 'Starting new conversation...'}
            </h2>
          </div>

          <div className="flex items-center gap-3">
             <button className="hidden sm:flex items-center gap-2 px-3 py-1.5 text-slate-500 hover:text-slate-800 transition-colors text-xs font-semibold rounded-lg hover:bg-slate-100">
                <i className="fa-solid fa-circle-question"></i>
                Help
             </button>
             <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center">
                <i className="fa-solid fa-user text-slate-400 text-xs"></i>
             </div>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 sm:px-6 py-8">
          <div className="max-w-4xl mx-auto w-full">
            {currentSession?.messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12 px-4 animate-in fade-in zoom-in duration-700">
                <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center mb-6 border border-indigo-100 shadow-sm">
                  <i className="fa-solid fa-graduation-cap text-indigo-600 text-4xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Welcome to ScholarBot</h3>
                <p className="text-slate-500 max-w-md mb-10 leading-relaxed">
                  Your intelligent academic companion. Ask me about your homework, school schedules, or any study topics!
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
                  {SUGGESTED_PROMPTS.map((prompt, idx) => (
                    <button
                      key={idx}
                      onClick={() => sendMessage(prompt)}
                      className="text-left px-5 py-4 bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-md hover:shadow-indigo-500/5 rounded-2xl transition-all duration-300 group"
                    >
                      <span className="text-slate-700 font-medium text-sm block mb-1 group-hover:text-indigo-700">{prompt}</span>
                      <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Quick Action</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              currentSession?.messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
              ))
            )}
            {isProcessing && !currentSession?.messages[currentSession.messages.length - 1]?.isStreaming && (
              <div className="flex gap-3 mb-6">
                <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center flex-shrink-0">
                  <i className="fa-solid fa-graduation-cap text-indigo-600 text-xs"></i>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none px-4 py-3 shadow-sm flex items-center gap-2">
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                  </div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest ml-1">Bot is thinking</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input Area */}
        <div className="px-4 sm:px-6 pb-6 pt-2 bg-white border-t border-slate-100">
          <div className="max-w-4xl mx-auto">
            {/* Attachments Preview */}
            {attachments.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {attachments.map((att, idx) => (
                  <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-50 h-16 w-16 shadow-sm">
                    <img src={`data:${att.file.type};base64,${att.base64}`} alt="Preview" className="w-full h-full object-cover" />
                    <button 
                      onClick={() => removeAttachment(idx)}
                      className="absolute -top-1 -right-1 bg-rose-500 text-white w-5 h-5 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                    >
                      <i className="fa-solid fa-xmark text-[10px]"></i>
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="relative flex items-end gap-3 p-1.5 bg-white border-2 border-slate-200 focus-within:border-indigo-500 rounded-2xl shadow-sm transition-all duration-300">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-slate-400 hover:text-indigo-600 transition-colors flex-shrink-0"
                title="Attach files or homework images"
              >
                <i className="fa-solid fa-paperclip text-lg"></i>
              </button>
              
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                multiple 
                accept="image/*"
              />

              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                placeholder="Type your academic question here..."
                className="flex-1 bg-transparent border-none focus:ring-0 text-slate-800 placeholder:text-slate-400 text-sm py-3 min-h-[44px] max-h-48 resize-none custom-scrollbar"
                rows={1}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = `${target.scrollHeight}px`;
                }}
              />

              <button
                onClick={() => sendMessage()}
                disabled={isProcessing || (!input.trim() && attachments.length === 0)}
                className={`flex-shrink-0 w-11 h-11 rounded-xl flex items-center justify-center transition-all duration-300 shadow-lg ${
                  isProcessing || (!input.trim() && attachments.length === 0)
                    ? 'bg-slate-100 text-slate-300'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-500/20 active:scale-95'
                }`}
              >
                <i className={`fa-solid ${isProcessing ? 'fa-spinner fa-spin' : 'fa-paper-plane'}`}></i>
              </button>
            </div>
            <div className="flex items-center justify-center mt-3 gap-6">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <i className="fa-solid fa-shield-halved text-indigo-400"></i>
                School-Safe Environment
              </span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <i className="fa-solid fa-brain text-indigo-400"></i>
                Powered by Gemini AI
              </span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
