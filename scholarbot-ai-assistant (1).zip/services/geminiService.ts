
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

// Initialize the Gemini API client with the environment variable directly as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateChatResponse = async (
  history: { role: string; parts: any[] }[],
  onChunk: (text: string) => void
) => {
  // Using gemini-3-pro-preview for complex academic tasks (math, coding, reasoning).
  const model = 'gemini-3-pro-preview';
  
  try {
    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      // Initialize chat with history excluding the most recent message.
      history: history.slice(0, -1),
    });

    const lastMessage = history[history.length - 1];
    // Check if the message is simple text or complex parts (including images).
    const messageParam = lastMessage.parts.length === 1 && lastMessage.parts[0].text 
      ? lastMessage.parts[0].text 
      : { parts: lastMessage.parts };

    const result = await chat.sendMessageStream({ message: messageParam });

    let fullText = "";
    for await (const chunk of result) {
      const responseChunk = chunk as GenerateContentResponse;
      // Access the generated text directly via the .text property as per guidelines.
      const text = responseChunk.text || "";
      fullText += text;
      onChunk(text);
    }
    
    return fullText;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      resolve(base64String.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });
};
